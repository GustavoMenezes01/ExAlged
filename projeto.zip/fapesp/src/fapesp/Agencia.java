package fapesp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Agencia {

	
	private List<Projeto>projetos;

	public Agencia() {
		super();
		projetos= new ArrayList<Projeto>();
	}
	
	public void addProjeto(Projeto projeto) {
	
		
		
		String titulo = JOptionPane.showInputDialog("Entre titulo:");
		projeto.setTitulo(titulo);
		projetos.add(projeto);
		
		int duracao = Integer.parseInt(JOptionPane.showInputDialog("Entre duracao:"));
		projeto.setDuracao(duracao);
		projetos.add(projeto);
		
	}
	
public void removerProjeto(Projeto projeto) {
		
	Scanner leitor = new Scanner(System.in);
    System.out.print("Qual o projeto deseja deletar");
   int escolha =  leitor.nextInt();

		projetos.remove(escolha);
		
	}

public void listarTodosProjetos(Projeto projeto) {
	
	for(Projeto c: projetos){
        System.out.println("--------------------------");
        System.out.println("projeto  : "+projetos.indexOf(c));
        System.out.println("titulo  : "+c.getTitulo());
        System.out.println("duracao  : "+c.getDuracao());
	}
	
}

public void listarProjeto(Projeto projeto) {
	
	Scanner leitor = new Scanner(System.in);
    System.out.print("Qual projeto deseja listar?");
    int escolha = leitor.nextInt();
	
	for(Projeto c: projetos){
		if(projetos.indexOf(c)==escolha) {
			
		
        System.out.println("--------------------------");
        System.out.println("projeto  : "+projetos.indexOf(c));
        System.out.println("titulo  : "+c.getTitulo());
        System.out.println("duracao  : "+c.getDuracao());
	}}
	
}
	
	public void alterarProjeto(Projeto projeto) {
		
		Scanner leitor = new Scanner(System.in);
	      System.out.print("Qual projeto deseja alterar?");
	      int escolha = leitor.nextInt();
	      
	      String novoTitulo = JOptionPane.showInputDialog("Projeto atual: "+projetos.get(escolha).getTitulo()+"\nEntre novo titulo:");
	      projeto.setTitulo(novoTitulo);
			
		}
	
	

}

