package fapesp;

import java.util.Scanner;

public class AgenciaApp {

	public static void main(String[] args) {
		
		AgenciaApp agenciaApp= new AgenciaApp();
		agenciaApp.execute();
		

	}
public void execute() {
	
	Agencia agencia = new Agencia();
	Projeto p = new Projeto();
	
    int escolha = 0;
    Scanner leitor = new Scanner(System.in);
 
    do{
       System.out.println("Sistema Fapesp");
       System.out.println("------------------");
       System.out.println("1) Inserir projeto");
       System.out.println("2) Listar projeto");
       System.out.println("3) Listar Todos projeto");
       System.out.println("4) Alterar projeto");
       System.out.println("5) Deletar projeto");
       System.out.println("6) Sair");
       System.out.println("------------------");
       System.out.println();
       System.out.print("Entre op��o -->");
       escolha = leitor.nextInt();
    
       System.out.println();
       System.out.println("op��o = "+escolha);
       System.out.println();
    
       if(escolha==1){
          agencia.addProjeto(p);
       }else if(escolha==2){
    	   agencia.listarProjeto(p);
       }else if(escolha==3){
          agencia.listarTodosProjetos(p);
       }else if(escolha==4){
          agencia.alterarProjeto(p);
       }else if(escolha==5){
    	   agencia.removerProjeto(p);
        }
    
    
    
    
    }while(escolha != 6);
    
    System.out.println("FIM - obrigado por utilizar nossos sistemas!");
	

}






}
