package fapesp;

public class Area {

	private int id;
	private String descricao;
	private GrandeArea grandeArea;
	public Area(int id, String descricao, GrandeArea grandeArea) {
		super();
		this.id = id;
		this.descricao = descricao;
		this.grandeArea = grandeArea;
	}
	public Area() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public GrandeArea getGrandeArea() {
		return grandeArea;
	}
	public void setGrandeArea(GrandeArea grandeArea) {
		this.grandeArea = grandeArea;
	}
	
	
	
	
	
	
}
