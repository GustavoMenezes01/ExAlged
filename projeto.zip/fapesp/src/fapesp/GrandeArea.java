package fapesp;

public class GrandeArea {

	private int id;
	private String descricao;
	
	public GrandeArea(int id, String descricao) {
		super();
		this.id = id;
		this.descricao = descricao;
	}

	public GrandeArea() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
	
	
	
}
