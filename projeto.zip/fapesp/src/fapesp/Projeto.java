package fapesp;

public class Projeto {

private int codigoInterno;	
private	String titulo;
private int duracao;
private double orcamento;
private Area   area;
private String dataEnvioAvaliacao;
private String dataResultadoAvaliacao;

public Projeto(int codigoInterno, String titulo, int duracao, double orcamento, Area area, String dataEnvioAvaliacao,
		String dataResultadoAvaliacao) {
	super();
	this.codigoInterno = codigoInterno;
	this.titulo = titulo;
	this.duracao = duracao;
	this.orcamento = orcamento;
	this.area = area;
	this.dataEnvioAvaliacao = dataEnvioAvaliacao;
	this.dataResultadoAvaliacao = dataResultadoAvaliacao;
}
public Projeto() {
	super();
}
public int getCodigoInterno() {
	return codigoInterno;
}
public void setCodigoInterno(int codigoInterno) {
	this.codigoInterno = codigoInterno;
}
public String getTitulo() {
	return titulo;
}
public void setTitulo(String titulo) {
	this.titulo = titulo;
}
public int getDuracao() {
	return duracao;
}
public void setDuracao(int duracao) {
	this.duracao = duracao;
}
public double getOrcamento() {
	return orcamento;
}
public void setOrcamento(double orcamento) {
	this.orcamento = orcamento;
}
public Area getArea() {
	return area;
}
public void setArea(Area area) {
	this.area = area;
}
public String getDataEnvioAvaliacao() {
	return dataEnvioAvaliacao;
}
public void setDataEnvioAvaliacao(String dataEnvioAvaliacao) {
	this.dataEnvioAvaliacao = dataEnvioAvaliacao;
}
public String getDataResultadoAvaliacao() {
	return dataResultadoAvaliacao;
}
public void setDataResultadoAvaliacao(String dataResultadoAvaliacao) {
	this.dataResultadoAvaliacao = dataResultadoAvaliacao;
}


	
	
	
}
